
public class Save {
    public static String USER[]=new String[100];
    public static String PASS[]=new String[100];
    public static String Email[]=new String[100];
    public static String name[]=new String[100];
}
