 public class User {
    String username;
    String password;
    String email;
    String nickname;
    int securityQuestionNumber;
    String securityAnswer;

     int level;
     int hp;
     int xp;
     int money;
     boolean isAdmin;

     User(String username, String password, String email, String nickname, int securityQuestionNumber, String securityAnswer) {
         this.username = username;
         this.password = password;
         this.email = email;
         this.nickname = nickname;
         this.securityQuestionNumber = securityQuestionNumber;
         this.securityAnswer = securityAnswer;
         this.level = 1;
         this.hp = 100;
         this.xp = 0;
         this.money = 100;
    }
}