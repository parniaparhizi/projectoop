import java.util.Scanner;

public class Admin {
    public static final String ADMIN_PASSWORD = "admin123";
    public static void handleAdminLogin(String command) {
        String[] parts = command.split(" ");
        if (parts.length != 3) {
            System.out.println("Invalid admin login command.");
            return;
        }
        String password = parts[2];
        if (password.equals(ADMIN_PASSWORD)) {
            Main.loggedInUser = new User("admin", ADMIN_PASSWORD, "admin@example.com", "Admin", 0, "");
            Main.loggedInUser.isAdmin = true;
            System.out.println("Admin logged in successfully.");
        } else {
            System.out.println("Invalid admin password.");
        }
    }

    public static void addCard() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter card name: ");
        String name = scanner.nextLine();
        if (Main.cards.stream().anyMatch(c -> c.name.equals(name))) {
            System.out.println("Error: Card with this name already exists.");
            return;
        }
        System.out.print("Enter attack/defense value (10-100): ");
        int attackDefense = Integer.parseInt(scanner.nextLine());
        System.out.print("Enter duration (1-5): ");
        int duration = Integer.parseInt(scanner.nextLine());
        System.out.print("Enter damage player (10-50): ");
        int damagePlayer = Integer.parseInt(scanner.nextLine());
        System.out.print("Enter level upgrade: ");
        int levelUpgrade = Integer.parseInt(scanner.nextLine());
        System.out.print("Enter cost upgrade: ");
        int costUpgrade = Integer.parseInt(scanner.nextLine());

        Main.Card newCard = new Main.Card(name, attackDefense, duration, damagePlayer, levelUpgrade, costUpgrade);
        System.out.print("Are you sure you want to add this card? (yes/no): ");
        String confirmation = scanner.nextLine();
        if (confirmation.equalsIgnoreCase("yes")) {
            Main.cards.add(newCard);
            System.out.println("Card added successfully.");
        } else {
            System.out.println("Card addition cancelled.");
        }
    }

    public static void removeCard(String cardName) {
        Main.Card cardToRemove = Main.cards.stream().filter(c -> c.name.equals(cardName)).findFirst().orElse(null);
        if (cardToRemove == null) {
            System.out.println("Error: Card not found.");
            return;
        }
        System.out.print("Are you sure you want to remove this card? (yes/no): ");
        Scanner scanner = new Scanner(System.in);
        String confirmation = scanner.nextLine();
        if (confirmation.equalsIgnoreCase("yes")) {
            Main.cards.remove(cardToRemove);
            System.out.println("Card removed successfully.");
        } else {
            System.out.println("Card removal cancelled.");
        }
    }

    public static void editCard(String cardName) {
        Main.Card cardToEdit = Main.cards.stream().filter(c -> c.name.equals(cardName)).findFirst().orElse(null);
        if (cardToEdit == null) {
            System.out.println("Error: Card not found.");
            return;
        }
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter new values (press enter to keep current value):");

        System.out.print("New attack/defense value (current: " + cardToEdit.attackDefense + "): ");
        String input = scanner.nextLine();
        if (!input.isEmpty()) {
            cardToEdit.attackDefense = Integer.parseInt(input);
        }

        System.out.print("Are you sure you want to edit this card? (yes/no): ");
        String confirmation = scanner.nextLine();
        if (confirmation.equalsIgnoreCase("yes")) {
            System.out.println("Card edited successfully.");
        } else {
            System.out.println("Card edit cancelled.");
        }
    }

    public static void showAllUsers() {
        for (User user : Main.users.values()) {
            System.out.println("Username: " + user.username);
            System.out.println("Email: " + user.email);
            System.out.println("Level: " + user.level);
            System.out.println("HP: " + user.hp);
            System.out.println("XP: " + user.xp);
            System.out.println("Money: " + user.money);
            System.out.println("--------------------");
        }
    }
}
