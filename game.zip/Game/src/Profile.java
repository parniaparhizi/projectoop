import java.util.Scanner;

public class Profile {
    public static void handleProfileMenu(String command) {
        if (command.equals("Show information")) {
            showUserInformation();
        } else if (command.startsWith("Profile change -u")) {
            changeUsername(command.split(" ")[3]);
        } else if (command.startsWith("Profile change -n")) {
            changeNickname(command.split(" ")[3]);
        } else if (command.equals("Profile change -e")) {
            changeEmail();
        } else if (command.startsWith("Profile change password")) {
            changePassword(command);
        } else {
            System.out.println("Invalid profile command.");
        }
    }

    private static void showUserInformation() {
        System.out.println("User Information:");
        System.out.println("Username: " + Main.loggedInUser.username);
        System.out.println("Nickname: " + Main.loggedInUser.nickname);
        System.out.println("Email: " + Main.loggedInUser.email);
        System.out.println("Level: " + Main.loggedInUser.level);
        System.out.println("HP: " + Main.loggedInUser.hp);
        System.out.println("XP: " + Main.loggedInUser.xp);
        System.out.println("Money: " + Main.loggedInUser.money);
    }

    private static void changeUsername(String newUsername) {
        if (newUsername.equals(Main.loggedInUser.username)) {
            System.out.println("Error: New username is the same as the current username.");
            return;
        }
        if (!newUsername.matches("^[a-zA-Z0-9]+$")) {
            System.out.println("Error: Username should only contain English letters and numbers.");
            return;
        }
        if (Main.users.containsKey(newUsername)) {
            System.out.println("Error: Username already exists.");
            return;
        }
        Main.users.remove(Main.loggedInUser.username);
        Main.loggedInUser.username = newUsername;
        Main.users.put(newUsername, Main.loggedInUser);
        System.out.println("Username changed successfully.");
    }

    private static void changeNickname(String newNickname) {
        if (newNickname.equals(Main.loggedInUser.nickname)) {
            System.out.println("Error: New nickname is the same as the current nickname.");
            return;
        }
        Main.loggedInUser.nickname = newNickname;
        System.out.println("Nickname changed successfully.");
    }

    private static void changeEmail() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter new email: ");
        String newEmail = scanner.nextLine();
        if (newEmail.equals(Main.loggedInUser.email)) {
            System.out.println("Error: New email is the same as the current email.");
            return;
        }
        if (!Register.validateEmail(newEmail)) {
            System.out.println("Error: Invalid email format.");
            return;
        }
        Main.loggedInUser.email = newEmail;
        System.out.println("Email changed successfully.");
    }

    private static void changePassword(String command) {
        String[] parts = command.split(" ");
        String oldPassword = parts[4];
        String newPassword = parts[6];

        if (!Main.loggedInUser.password.equals(oldPassword)) {
            System.out.println("Error: Old password is incorrect.");
            return;
        }

        if (oldPassword.equals(newPassword)) {
            System.out.println("Error: New password is the same as the old password.");
            return;
        }

        if (!Register.validatePassword(newPassword)) {
            System.out.println("Error: Password should be at least 8 characters long and contain uppercase, lowercase, number, and special character.");
            return;
        }

        System.out.print("Please enter your new password again: ");
        Scanner scanner = new Scanner(System.in);
        String confirmPassword = scanner.nextLine();

        if (!confirmPassword.equals(newPassword)) {
            System.out.println("Error: Passwords do not match.");
            return;
        }

        Main.loggedInUser.password = newPassword;
        System.out.println("Password changed successfully.");
    }
}
