import java.util.*;

public class Register {
    public static void handleRegistration(String command) {
        String[] parts = command.split(" ");
        String username = "", password = "", email = "", nickname = "";
        for (int i = 2; i < parts.length; i += 2) {
            switch (parts[i]) {
                case "-u": username = parts[i + 1]; break;
                case "-p": password = parts[i + 1]; break;
                case "-email": email = parts[i + 1]; break;
                case "-n": nickname = parts[i + 1]; break;
            }
        }

        if (username.isEmpty() || password.isEmpty() || email.isEmpty() || nickname.isEmpty()) {
            System.out.println("Error: All fields must be filled.");
            return;
        }

        if (Main.users.containsKey(username)) {
            System.out.println("Error: Username already exists.");
            return;
        }

        if (!username.matches("^[a-zA-Z0-9]+$")) {
            System.out.println("Error: Username should only contain English letters and numbers.");
            return;
        }

        if (password.equals("random")) {
            password = generateRandomPassword();
            System.out.println("Your random password: " + password);
            System.out.print("Please enter your password: ");
            Scanner scanner = new Scanner(System.in);
            String confirmPassword = scanner.nextLine();
            if (!confirmPassword.equals(password)) {
                System.out.println("Error: Passwords do not match.");
                return;
            }
        }

        if (!validatePassword(password)) {
            System.out.println("Error: Password should be at least 8 characters long and contain uppercase, lowercase, number, and special character.");
            return;
        }

        if (!validateEmail(email)) {
            System.out.println("Error: Invalid email format.");
            return;
        }

        System.out.println("User created successfully.");
        System.out.println("Please choose a security question:");
        System.out.println("1-What is your father's name?");
        System.out.println("2-What is your favorite color?");
        System.out.println("3-What was the name of your first pet?");

        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter command (question pick -q question -a answer -c confirm answer): ");
        String securityCommand = scanner.nextLine();
        String[] secParts = securityCommand.split(" ");
        int questionNumber = Integer.parseInt(secParts[3]);
        String answer = secParts[5];
        String confirmAnswer = secParts[7];

        if (!answer.equals(confirmAnswer)) {
            System.out.println("Error: Answers do not match.");
            return;
        }

        String captcha = generateCaptcha();
        System.out.println("Please solve this captcha: " + captcha);
        System.out.print("Your answer: ");
        String captchaAnswer = scanner.nextLine();
        if (!verifyCaptcha(captchaAnswer, captcha)) {
            System.out.println("Error: Incorrect captcha.");
            return;
        }

        Main.users.put(username, new User(username, password, email, nickname, questionNumber, answer));
        System.out.println("Registration successful!");
    }

    private static String generateRandomPassword() {
        String upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        String lower = upper.toLowerCase();
        String digits = "0123456789";
        StringBuilder password = getStringBuilder(upper, lower, digits);
        List<Character> pwdChars = new ArrayList<>();
        for (char c : password.toString().toCharArray()) {
            pwdChars.add(c);
        }
        Collections.shuffle(pwdChars);
        return pwdChars.stream().map(String::valueOf).collect(java.util.stream.Collectors.joining());
    }

    private static StringBuilder getStringBuilder(String upper, String lower, String digits) {
        String specialChars = "!@#$%^&*()_+-=[]{}|;:,.<>?";
        String allChars = upper + lower + digits + specialChars;
        Random random = new Random();
        StringBuilder password = new StringBuilder();
        password.append(upper.charAt(random.nextInt(upper.length())));
        password.append(lower.charAt(random.nextInt(lower.length())));
        password.append(digits.charAt(random.nextInt(digits.length())));
        password.append(specialChars.charAt(random.nextInt(specialChars.length())));
        for (int i = 4; i < 8; i++) {
            password.append(allChars.charAt(random.nextInt(allChars.length())));
        }
        return password;
    }

    public static boolean validatePassword(String password) {
        return password.length() >= 8 &&
                password.matches(".*[A-Z].*") &&
                password.matches(".*[a-z].*") &&
                password.matches(".*\\d.*") &&
                password.matches(".*[!@#$%^&*()_+-=\\[\\]{}|;:,.<>?].*");
    }

    public static boolean validateEmail(String email) {
        return email.matches("^[A-Za-z0-9+_.-]+@(.+)$");
    }

    private static String generateCaptcha() {
        Random random = new Random();
        int num1 = random.nextInt(10);
        int num2 = random.nextInt(10);
        return num1 + " PLUS " + num2;
    }

    private static boolean verifyCaptcha(String userAnswer, String captcha) {
        String[] parts = captcha.split(" ");
        int correctAnswer = Integer.parseInt(parts[0]) + Integer.parseInt(parts[2]);
        return Integer.parseInt(userAnswer) == correctAnswer;
    }
}
