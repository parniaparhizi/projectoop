import java.time.Duration;
import java.time.Instant;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Login {
    public static Map<String, Integer> loginAttempts = new HashMap<>();
    public static Map<String, Instant> lockoutTimes = new HashMap<>();
    public static void handleLogin(String command) {
        if (Main.loggedInUser != null) {
            System.out.println("Error: A user is already logged in.");
            return;
        }

        String[] parts = command.split(" ");
        String username = parts[3];
        String password = parts[5];

        if (!Main.users.containsKey(username)) {
            System.out.println("Error: Username doesn't exist!");
            return;
        }

        if (isUserLockedOut(username)) {
            System.out.println("Account is locked. Try again later.");
            return;
        }

        User user = Main.users.get(username);
        if (!user.password.equals(password)) {
            handleFailedLogin(username);
            return;
        }

        Main.loggedInUser = user;
        loginAttempts.remove(username);
        System.out.println("User logged in successfully!");
    }

    private static void handleFailedLogin(String username) {
        loginAttempts.put(username, loginAttempts.getOrDefault(username, 0) + 1);
        int attempts = loginAttempts.get(username);
        if (attempts >= 3) {
            lockoutTimes.put(username, Instant.now().plusSeconds(attempts * 5L));
            System.out.println("Too many failed attempts. Try again in " + (attempts * 5) + " seconds.");
        } else {
            System.out.println("Error: Password and Username don't match!");
        }
    }

    private static boolean isUserLockedOut(String username) {
        if (lockoutTimes.containsKey(username)) {
            Instant lockoutTime = lockoutTimes.get(username);
            if (Instant.now().isBefore(lockoutTime)) {
                long remainingSeconds = Duration.between(Instant.now(), lockoutTime).getSeconds();
                System.out.println("Account is locked. Try again in " + remainingSeconds + " seconds.");
                return true;
            } else {
                lockoutTimes.remove(username);
            }
        }
        return false;
    }

    public static void handleForgotPassword(String command) {
        String[] parts = command.split(" ");
        String username = parts[3];

        if (!Main.users.containsKey(username)) {
            System.out.println("Error: Username doesn't exist!");
            return;
        }

        User user = Main.users.get(username);
        System.out.println("Security Question: " + getSecurityQuestion(user.securityQuestionNumber));
        Scanner scanner = new Scanner(System.in);
        System.out.print("Your answer: ");
        String answer = scanner.nextLine();

        if (answer.equals(user.securityAnswer)) {
            System.out.println("Your password is: " + user.password);
        } else {
            System.out.println("Incorrect answer. Password recovery failed.");
        }
    }


    private static String getSecurityQuestion(int questionNumber) {
        switch (questionNumber) {
            case 1: return "What is your father's name?";
            case 2: return "What is your favorite color?";
            case 3: return "What was the name of your first pet?";
            default: return "Invalid question number";
        }
    }

    public static void handleLogout() {
        if (Main.loggedInUser == null) {
            System.out.println("No user is currently logged in.");
        } else {
            Main.loggedInUser = null;
            System.out.println("User logged out successfully.");
        }
    }
}
