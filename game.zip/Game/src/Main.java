import java.util.*;
import java.time.*;

public class Main {
    public static Map<String, User> users = new HashMap<>();
    public static User loggedInUser = null;
    public static List<Card> cards = new ArrayList<>();
    public static List<SpecialCard> specialCards = new ArrayList<>();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Well come to the Game:)");
        while (true) {
            System.out.print("> ");
            String command = scanner.nextLine();
            if (command.startsWith("user create")) {
                Register.handleRegistration(command);
            } else if (command.startsWith("user login")) {
                Login.handleLogin(command);
            } else if (command.equals("logout")) {
                Login.handleLogout();
            } else if (command.startsWith("Forgot my password")) {
                Login.handleForgotPassword(command);
            } else if (loggedInUser != null && command.startsWith("Profile")) {
                Profile.handleProfileMenu(command);
            } else if (command.startsWith("login admin")) {
                Admin.handleAdminLogin(command);
            } else if (loggedInUser != null && loggedInUser.isAdmin && command.startsWith("add card")) {
                Admin.addCard();
            } else if (loggedInUser != null && loggedInUser.isAdmin && command.startsWith("remove card")) {
                Admin.removeCard(command.split(" ")[2]);
            } else if (loggedInUser != null && loggedInUser.isAdmin && command.startsWith("edit card")) {
                Admin.editCard(command.split(" ")[2]);
            } else if (loggedInUser != null && loggedInUser.isAdmin && command.equals("show users")) {
                Admin.showAllUsers();
            } else if (command.equals("exit")) {
                break;
            } else {
                System.out.println("Invalid command. Please try again.");
            }
        }
        scanner.close();
    }

    private static void initializeSpecialCards() {
        specialCards.add(new SpecialCard("Shield", "Blocks any card with any damage."));
        specialCards.add(new SpecialCard("Heal", "Adds HP to the player."));
        specialCards.add(new SpecialCard("Power Boost", "Randomly buffs one of the played cards."));
        specialCards.add(new SpecialCard("Hole Mover", "Randomly changes the location of destroyed blocks for both players."));
        specialCards.add(new SpecialCard("Repairer", "Can be played on holes to repair them."));
        specialCards.add(new SpecialCard("Round Reducer", "Reduces the number of rounds by one."));
        specialCards.add(new SpecialCard("Card Stealer", "Randomly transfers one of the opponent's cards to the player's hand."));
        specialCards.add(new SpecialCard("Opponent Weakener", "Randomly selects two of the opponent's cards and reduces their damage and power."));
        specialCards.add(new SpecialCard("Copier", "Creates a copy of one of the player's cards."));
        specialCards.add(new SpecialCard("Hider", "Hides and randomizes the opponent's cards in the next round."));
    }

    static class Card {
        String name;
        int attackDefense;
        int duration;
        int damagePlayer;
        int levelUpgrade;
        int costUpgrade;

        Card(String name, int attackDefense, int duration, int damagePlayer, int levelUpgrade, int costUpgrade) {
            this.name = name;
            this.attackDefense = attackDefense;
            this.duration = duration;
            this.damagePlayer = damagePlayer;
            this.levelUpgrade = levelUpgrade;
            this.costUpgrade = costUpgrade;
        }
    }

    static class SpecialCard {
        String name;
        String effect;

        SpecialCard(String name, String effect) {
            this.name = name;
            this.effect = effect;
        }
    }
}